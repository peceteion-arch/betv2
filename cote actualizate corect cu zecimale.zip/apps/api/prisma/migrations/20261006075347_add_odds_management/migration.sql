-- AlterTable
ALTER TABLE "odds" ADD COLUMN     "enabled" BOOLEAN NOT NULL DEFAULT true,
ADD COLUMN     "original_value" DECIMAL(10,2);

-- CreateTable
CREATE TABLE "odds_changes" (
    "id" TEXT NOT NULL,
    "match_id" TEXT NOT NULL,
    "market" TEXT NOT NULL,
    "selection" TEXT NOT NULL,
    "old_value" DECIMAL(10,2),
    "new_value" DECIMAL(10,2),
    "oldEnabled" BOOLEAN NOT NULL,
    "newEnabled" BOOLEAN NOT NULL,
    "admin_id" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "odds_changes_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "odds_changes_match_id_idx" ON "odds_changes"("match_id");

-- AddForeignKey
ALTER TABLE "odds_changes" ADD CONSTRAINT "odds_changes_admin_id_fkey" FOREIGN KEY ("admin_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
