import { describe, it, expect, beforeEach, vi } from 'vitest';
import { matchService } from '../src/services/match.service';
import { betService } from '../src/services/bet.service';
import { prisma } from '../src/lib/prisma';

vi.mock('../src/lib/prisma', () => ({
  prisma: {
    match: {
      findUnique: vi.fn(),
      update: vi.fn(),
    },
    odds: {
      findUnique: vi.fn(),
      findFirst: vi.fn(),
      update: vi.fn(),
      createMany: vi.fn(),
    },
    oddsChange: {
      create: vi.fn(),
    },
    $transaction: async (fn: any) => await fn({
      match: prisma.match,
      odds: prisma.odds,
      oddsChange: prisma.oddsChange,
    }),
  },
}));

describe('Odds Management', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('should update odds and create history', async () => {
    (prisma.match.findUnique as any).mockResolvedValue({ id: 'm1', status: 'SCHEDULED', matchDate: new Date(Date.now() + 86400000) });
    (prisma.odds.findUnique as any).mockResolvedValue({ id: 'o1', value: 1.90, enabled: true, originalValue: 1.90 });

    const changes = [{ market: '1X2', selection: '1', value: 2.10, enabled: true }];
    await matchService.updateOdds('m1', 'admin1', changes);

    expect(prisma.odds.update).toHaveBeenCalledWith(expect.objectContaining({
      data: expect.objectContaining({ value: 2.10, source: 'manual' })
    }));
    expect(prisma.oddsChange.create).toHaveBeenCalled();
  });

  it('should throw error if match is not SCHEDULED', async () => {
    (prisma.match.findUnique as any).mockResolvedValue({ id: 'm1', status: 'LIVE' });
    await expect(matchService.updateOdds('m1', 'admin1', [])).rejects.toThrow('Only scheduled matches can have odds edited');
  });
});

describe('Bet Placement with Odds Validation', () => {
  it('should throw OddsChangedError if odds differ', async () => {
    (prisma.user.findUnique as any).mockResolvedValue({ id: 'u1', balance: 100, isBlocked: false });
    (prisma.match.findUnique as any).mockResolvedValue({ id: 'm1', status: 'SCHEDULED', matchDate: new Date(Date.now() + 86400000), homeTeam: { name: 'T1' }, awayTeam: { name: 'T2' } });
    (prisma.odds.findFirst as any).mockResolvedValue({ value: 2.10, enabled: true });

    const selections = [{ matchId: 'm1', market: '1X2', selection: '1', odds: 1.90 }];

    try {
      await betService.placeBet('u1', 10, selections);
    } catch (e: any) {
      expect(e.name).toBe('OddsChangedError');
      expect(e.changes[0].newOdds).toBe(2.10);
    }
  });

  it('should throw error if selection is disabled', async () => {
    (prisma.user.findUnique as any).mockResolvedValue({ id: 'u1', balance: 100, isBlocked: false });
    (prisma.match.findUnique as any).mockResolvedValue({ id: 'm1', status: 'SCHEDULED', matchDate: new Date(Date.now() + 86400000), homeTeam: { name: 'T1' }, awayTeam: { name: 'T2' } });
    (prisma.odds.findFirst as any).mockResolvedValue({ value: 1.90, enabled: false });

    const selections = [{ matchId: 'm1', market: '1X2', selection: '1', odds: 1.90 }];
    await expect(betService.placeBet('u1', 10, selections)).rejects.toThrow('nu mai este disponibilă');
  });
});