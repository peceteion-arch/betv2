/*
  Warnings:

  - You are about to drop the column `emoji` on the `competitions` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "competitions" DROP COLUMN "emoji",
ADD COLUMN     "active" BOOLEAN NOT NULL DEFAULT true;
