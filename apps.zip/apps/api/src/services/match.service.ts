import { prisma } from '../lib/prisma';
import { env, SCOREABLE_MATCH_STATUSES } from '../config/env';
import { Prisma } from '@prisma/client';
import { serializeMatch } from '../lib/match.serializer';
import { settleRunning } from '../lib/settlement-lock';
import { oddsEvents } from '../lib/odds-events';
import { matchHistoryProvider } from '../odds-engine/providers/match-history.provider';
import { computeTeamRatings, expectedGoalsFromRatings } from '../odds-engine/features/team-ratings.features';
import { calculateMarketProbabilities } from '../odds-engine/features/poisson-market.engine';
import { buildOddsFromProbabilities } from '../odds-engine/features/odds-from-probabilities';

// Odds.value is @db.Decimal, so Prisma hands it back as a Decimal that
// serialises to a JSON string ("1.90"). The UI calls .toFixed() on it, which
// only exists on numbers, so every match read has to be normalised before it
// leaves the API. listAll() in particular feeds the admin table, which reads
// the same field.
const mapOdds = (odds: any[]) =>
  odds.map((o) => ({ ...o, value: Number(o.value) }));

export const matchService = {

  mapStatus(apiStatus: string): string {
    const statusMap: Record<string, string> = {
      SCHEDULED: 'SCHEDULED',
      TIMED: 'SCHEDULED',
      IN_PLAY: 'LIVE',
      PAUSED: 'LIVE',
      FINISHED: 'FINISHED',
      POSTPONED: 'POSTPONED',
      CANCELLED: 'CANCELLED',
    };
    return statusMap[apiStatus] || 'SCHEDULED';
  },


  async listUpcoming(limit: number = 20, cursor?: string, isAdmin: boolean = false) {
    const now = new Date();
    const query: Prisma.MatchFindManyArgs & { include: { odds: true, homeTeam: true, awayTeam: true, competition: true } } = {
      where: {
        matchDate: { gte: now },
        status: 'SCHEDULED',
      },
      include: { odds: true, homeTeam: true, awayTeam: true, competition: true },
      orderBy: { matchDate: 'asc' },
      take: limit + 1,
    };

    if (cursor) {
      query.cursor = { id: cursor };
      query.skip = 1;
    }

    const matches = await prisma.match.findMany(query);
    const hasMore = matches.length > limit;

    const items = (hasMore ? matches.slice(0, limit) : matches).map((m) => {
      let odds = mapOdds(m.odds);
      if (!isAdmin) {
        odds = odds.filter(o => o.enabled);
      }
      return {
        ...serializeMatch(m),
        odds,
      };
    });

    const filteredItems = isAdmin
      ? items
      : items.filter(m => m.odds.length > 0);

    return {
      items: filteredItems,
      nextCursor: hasMore ? items[items.length - 1]?.id : null,
    };
  },

  async listLive(limit: number = 50, isAdmin: boolean = false) {
    const now = new Date();
    const matches = await prisma.match.findMany({
      where: {
        OR: [
          { status: 'LIVE' },
          { AND: [{ status: 'SCHEDULED' }, { matchDate: { lte: now } }] },
        ],
      },
      include: { odds: true, homeTeam: true, awayTeam: true, competition: true },
      orderBy: { matchDate: 'desc' },
      take: limit,
    });

    return matches.map((m) => {
      let odds = mapOdds(m.odds);
      if (!isAdmin) {
        odds = odds.filter(o => o.enabled);
      }
      return {
        ...serializeMatch(m),
        odds,
      };
    }).filter(m => isAdmin || m.odds.length > 0);
  },

  async getById(id: string, isAdmin: boolean = false) {
    const match = await prisma.match.findUnique({
      where: { id },
      include: { odds: true, homeTeam: true, awayTeam: true, competition: true },
    });
    if (!match) throw new Error('Match not found');

    let odds = mapOdds(match.odds);
    if (!isAdmin) {
      odds = odds.filter(o => o.enabled);
    }

    return { ...serializeMatch(match), odds };
  },

  // Admin panel listing: every match regardless of status, no pagination.
  // We also surface a `betSelectionCount` per match so the admin edit UI can
  // decide which fields are frozen (see updateMatch).
  async listAll(isAdmin: boolean = false) {
    const matches = await prisma.match.findMany({
      include: { odds: true, homeTeam: true, awayTeam: true, competition: true },
      orderBy: { matchDate: 'desc' },
    });

    const matchIds = matches.map((m) => m.id);
    const counts =
      matchIds.length === 0
        ? []
        : await prisma.betSelection.groupBy({
            by: ['matchId'],
            where: { matchId: { in: matchIds } },
            _count: { _all: true },
          });
    const countMap = new Map(counts.map((c) => [c.matchId, c._count._all ?? 0]));

    return matches.map((m) => {
      let odds = mapOdds(m.odds);
      if (!isAdmin) {
        odds = odds.filter(o => o.enabled);
      }
      return {
        ...serializeMatch(m),
        odds,
        betSelectionCount: countMap.get(m.id) ?? 0,
      };
    }).filter(m => isAdmin || m.odds.length > 0);
  },

  async createManual(data: {
    homeTeamId: string;
    awayTeamId: string;
    competitionId?: string;
    league?: string;
    matchday: number;
    matchDate: string;
  }) {
    // Validate: teams must be different
    if (data.homeTeamId === data.awayTeamId) {
      throw new Error('Home and away teams must be different');
    }

    const competitionId = data.competitionId?.trim() || undefined;
    const league = data.league?.trim() || undefined;

    // Validate: at least one of competitionId or league is provided
    if (!competitionId && !league) {
      throw new Error('Either competitionId or league must be provided');
    }

    // Validate: if competitionId is provided, ensure it exists
    let competition = null;
    if (competitionId) {
      competition = await prisma.competition.findUnique({
        where: { id: competitionId },
      });
      if (!competition) {
        throw new Error(`Competition not found: ${competitionId}`);
      }
    }

    // Validate: teams exist
    const [homeTeam, awayTeam] = await prisma.$transaction([
      prisma.team.findUnique({ where: { id: data.homeTeamId } }),
      prisma.team.findUnique({ where: { id: data.awayTeamId } }),
    ]);

    if (!homeTeam) throw new Error(`Home team not found: ${data.homeTeamId}`);
    if (!awayTeam) throw new Error(`Away team not found: ${data.awayTeamId}`);

    // Validate matchday >= 1
    if (data.matchday < 1) {
      throw new Error('Matchday must be at least 1');
    }

    // Timestamp suffix keeps externalId unique so the same pairing can be
    // scheduled twice on different dates.
    const slug = (s: string) => s.toLowerCase().replace(/\s+/g, '-');
    const externalId = `manual-${slug(homeTeam.name)}-${slug(awayTeam.name)}-${Date.now()}`;

    // Explicitly interpret the admin-entered datetime-local value as
    // Europe/Bucharest and store the corresponding UTC instant.
    // The datetime-local input (e.g. "2026-10-01T20:00") carries no timezone.
    // We treat it as Bucharest time and convert to UTC.
    const { fromZonedTime } = await import('date-fns-tz');
    const utcMatchDate = fromZonedTime(data.matchDate, 'Europe/Bucharest');

    const newMatchData: Prisma.MatchUncheckedCreateInput = {
      externalId,
      homeTeamId: data.homeTeamId,
      awayTeamId: data.awayTeamId,
      competitionId: competitionId ?? null,
      league: league ?? null,
      matchday: data.matchday,
      matchDate: utcMatchDate,
      status: 'SCHEDULED',
    };

    const newMatch = await prisma.match.create({ data: newMatchData });

    await this.generateOdds(newMatch.id);

    const created = await prisma.match.findUnique({
      where: { id: newMatch.id },
      include: { odds: true, homeTeam: true, awayTeam: true, competition: true },
    });
    return created && { ...serializeMatch(created), odds: mapOdds(created.odds) };
  },

  async updateScore(id: string, data: { homeScore: number; awayScore: number; status: string; isForfeit?: boolean }) {
    // The zod schema already restricts status to LIVE/FINISHED, but this is the
    // layer that actually writes the column, so it re-checks. Two reasons it
    // must not accept anything else: SCHEDULED re-opens a finished match for
    // betting (placeBet only requires SCHEDULED + a future matchDate), and VOID
    // bypasses voidMatch(), which is the deliberate two-step for voiding.
    if (!SCOREABLE_MATCH_STATUSES.includes(data.status as (typeof SCOREABLE_MATCH_STATUSES)[number])) {
      throw new Error('Estado inválido para atualizar resultado');
    }

    const existing = await prisma.match.findUnique({ where: { id }, select: { status: true } });
    if (!existing) throw new Error('Jogo não encontrado');
    // Scoring a voided match would silently re-admit it to accumulators. The
    // operator has to explicitly lift the void first.
    if (existing.status === 'VOID') throw new Error('Jogo marcado como VOID - anula o VOID antes de atualizar o resultado');
    // A FINISHED match may still be corrected, but only while nothing has been
    // paid out on it. Once settlement has decided any ticket that holds a leg on
    // this match (WON/LOST), those flags and balances were computed from the old
    // score and nothing here would redo them, so the result is frozen.
    // CANCELLED tickets were refunded regardless of the result, and PENDING
    // tickets have not used it yet, so neither blocks a correction.
    if (existing.status === 'FINISHED') {
      // Settlement writes ticket status and balances in one run; correcting the
      // score while it is in flight could slip between its read and its write.
      if (settleRunning) {
        throw new Error('Settlement em curso - tenta novamente dentro de instantes');
      }
      const settledTickets = await prisma.bet.count({
        where: {
          status: { in: ['WON', 'LOST'] },
          selections: { some: { matchId: id } },
        },
      });
      if (settledTickets > 0) {
        throw new Error(
          `Não é possível corrigir o resultado: ${settledTickets} aposta(s) neste jogo já foram decidise (settlement executado).`
        );
      }
    }

    const updateData: Prisma.MatchUncheckedUpdateInput = {
      homeScore: data.homeScore,
      awayScore: data.awayScore,
      status: data.status,
    };
    if (data.isForfeit !== undefined) {
      updateData.isForfeit = data.isForfeit;
    }

    await prisma.match.update({
      where: { id },
      data: updateData,
    });

    const updated = await prisma.match.findUnique({
      where: { id },
      include: { odds: true, homeTeam: true, awayTeam: true, competition: true },
    });
    return updated && { ...serializeMatch(updated), odds: mapOdds(updated.odds) };
  },

  // Admin marks an event as void. This is NOT a 0-0 result and NOT a
  // FINISHED match: the event produced no playable outcome, so its selections
  // drop out of any accumulator at odds 1.00. Scores are deliberately left
  // untouched so a void never fabricates a result.
  async voidMatch(id: string) {
    const match = await prisma.match.findUnique({ where: { id }, select: { id: true, status: true } });
    if (!match) throw new Error('Jogo não encontrado');
    if (match.status === 'VOID') throw new Error('Jogo já está marcado como VOID');

    await prisma.match.update({
      where: { id },
      data: {
        status: 'VOID',
        previousStatus: match.status, // Store the current status before voiding
      },
    });

    const updatedWithOdds = await prisma.match.findUnique({
      where: { id },
      include: { odds: true, homeTeam: true, awayTeam: true, competition: true },
    });
    if (!updatedWithOdds) throw new Error('Jogo não encontrado após atualização');
    return { ...serializeMatch(updatedWithOdds), odds: mapOdds(updatedWithOdds.odds) };
  },

  // Clears a void so the match can be scored normally again. Without this an
  // accidental void would permanently strip the event from every ticket.
  async unvoidMatch(id: string) {
    const match = await prisma.match.findUnique({ where: { id }, select: { id: true, status: true, previousStatus: true } });
    if (!match) throw new Error('Jogo não encontrado');
    if (match.status !== 'VOID') throw new Error('Jogo não está marcado como VOID');

    await prisma.match.update({
      where: { id },
      data: {
        status: match.previousStatus ?? 'SCHEDULED', // Restore previous status or default to SCHEDULED
        previousStatus: null, // Clear the previous status after restoration
      },
    });

    const updatedWithOdds = await prisma.match.findUnique({
      where: { id },
      include: { odds: true, homeTeam: true, awayTeam: true, competition: true },
    });
    if (!updatedWithOdds) throw new Error('Jogo não encontrado após atualização');
    return { ...serializeMatch(updatedWithOdds), odds: mapOdds(updatedWithOdds.odds) };
  },

  // Refuses to delete a match that already has bets on it, so settled history
  // can never be orphaned. Returns the bet count so the route can report 409.
  async deleteMatch(id: string) {
    const bets = await prisma.betSelection.count({ where: { matchId: id } });
    if (bets > 0) return { deleted: false as const, bets };

    await prisma.match.delete({ where: { id } });
    return { deleted: true as const, bets: 0 };
  },

  /**
   * Generates odds for a new match using the statistical engine.
   *
   * Flow:
   * 1. Check if odds already exist (protects against re-generation)
   * 2. Protect manual odds from being overwritten (skip if source='manual')
   * 3. Fetch eligible historical matches from all competitions
   * 4. Compute team ratings and expected goals
   * 5. Calculate market probabilities via Poisson model
   * 6. Convert to odds using buildOddsFromProbabilities()
   * 7. Store only the newly-estimated odds
   */
  async generateOdds(matchId: string) {
    // Already generated — skip (do not regenerate on every read).
    const existingOdds = await prisma.odds.findMany({ where: { matchId } });
    if (existingOdds.length > 0) return;

    const match = await prisma.match.findUnique({
      where: { id: matchId },
      select: {
        id: true,
        homeTeamId: true,
        awayTeamId: true,
        competitionId: true,
        matchDate: true,
      },
    });
    if (!match) return;

    // Never overwrite odds that an operator has already marked as manual.
    const manualExists = await prisma.odds.findFirst({
      where: { matchId, source: 'manual' },
    });
    if (manualExists) return;

    const asOf = new Date(match.matchDate);

    // If no history is available at all, fall back to simple base odds (still
    // stored as 'estimated'). This keeps the match displayable while the
    // statistical model is still cold.
    try {
      const history = await matchHistoryProvider.getGlobalMatches(asOf);
      if (history.length > 0) {
        // Statistical path: connect the statistical engine to the generation flow.
        await this._generateOddsFromStats(match, history, asOf);
      } else {
        await this._generateFallbackOdds(matchId);
      }
    } catch {
      // Provider query failed — do not let this block match creation.
      await this._generateFallbackOdds(matchId);
    }
  },

  async _generateOddsFromStats(
    match: { id: string; homeTeamId: string; awayTeamId: string; competitionId: string | null; matchDate: Date },
    history: Array<any>,
    asOf: Date
  ): Promise<void> {
    const ratingsResult = computeTeamRatings(history, asOf, {
      competitionId: match.competitionId ?? undefined,
    });

    const expectedGoals = expectedGoalsFromRatings(
      ratingsResult,
      match.homeTeamId,
      match.awayTeamId
    );

    if (!expectedGoals.lambdaA || !expectedGoals.lambdaB) {
      // Missing team ratings (no data for these teams) → fallback.
      await this._generateFallbackOdds(match.id);
      return;
    }

    const marketProbs = calculateMarketProbabilities(expectedGoals.lambdaA, expectedGoals.lambdaB);

    if (!marketProbs.valid || !marketProbs.converged) {
      await this._generateFallbackOdds(match.id);
      return;
    }

    const oddsLines = buildOddsFromProbabilities(marketProbs, {
      margin: 0.07,
      correctScoreMargin: 0.15,
    });
    if (!oddsLines) {
      await this._generateFallbackOdds(match.id);
      return;
    }

    const oddsToCreate = oddsLines.map(odds => ({
      matchId: match.id,
      market: odds.market,
      selection: odds.selection,
      value: odds.value,
      source: 'estimated',
    }));
    await prisma.odds.createMany({ data: oddsToCreate });
  },

  /** Fallback odds used when the statistical engine cannot produce results.
   * These are deterministic base values — no random jitter — so the same
   * match always gets the same fallback odds and test reproducibility is kept.
   */
  async _generateFallbackOdds(matchId: string) {

    const markets = [
      { market: '1X2', selections: ['1', 'X', '2'] },
      { market: 'DUPLA_HIPOTESE', selections: ['1X', 'X2', '12'] },
      { market: 'MARCAS_0_5', selections: ['Mais 0.5', 'Menos 0.5'] },
      { market: 'MARCAS_1_5', selections: ['Mais 1.5', 'Menos 1.5'] },
      { market: 'MARCAS_2_5', selections: ['Mais 2.5', 'Menos 2.5'] },
      { market: 'MARCAS_3_5', selections: ['Mais 3.5', 'Menos 3.5'] },
      { market: 'MARCAS_4_5', selections: ['Mais 4.5', 'Menos 4.5'] },
      { market: 'AMBAS_MARCAM', selections: ['Sim', 'Não'] },
      { market: 'RESULTADO_CORRETO', selections: ['1-0', '2-0', '2-1', '0-0', '1-1', '2-2', '0-1', '0-2', '1-2'] },
      { market: 'IMPAR_PAR', selections: ['Ímpar', 'Par'] },
    ];

    const baseOdds: Record<string, number[]> = {
      '1X2': [1.90, 3.50, 3.80],
      'DUPLA_HIPOTESE': [1.30, 1.80, 1.25],
      'MARCAS_0_5': [1.08, 9.50],
      'MARCAS_1_5': [1.35, 3.20],
      'MARCAS_2_5': [1.85, 1.95],
      'MARCAS_3_5': [2.60, 1.50],
      'MARCAS_4_5': [3.40, 1.30],
      'AMBAS_MARCAM': [1.75, 2.05],
      'RESULTADO_CORRETO': [5.50, 7.00, 8.50, 9.00, 5.80, 12.00, 6.50, 8.00, 9.50],
      'IMPAR_PAR': [1.90, 1.90],
    };

    const oddsToCreate: Array<{ matchId: string; market: string; selection: string; value: number; source: string }> = [];

    for (const market of markets) {
      const base = baseOdds[market.market];
      for (let i = 0; i < market.selections.length; i++) {
        const value = base ? base[i] : 2.00;
        oddsToCreate.push({
          matchId,
          market: market.market,
          selection: market.selections[i],
          value: Math.round(value * 100) / 100,
          source: 'estimated',
        });
      }
    }

    await prisma.odds.createMany({ data: oddsToCreate });
  },

  async updateOdds(matchId: string, adminId: string, changes: Array<{ market: string, selection: string, value?: number, enabled?: boolean }>) {
    return await prisma.$transaction(async (tx) => {
      const match = await tx.match.findUnique({ where: { id: matchId } });
      if (!match) throw new Error('Match not found');
      if (match.status !== 'SCHEDULED') throw new Error('Only scheduled matches can have odds edited');
      if (new Date(match.matchDate).getTime() <= Date.now()) throw new Error('Match has already started');

      const results = [];
      for (const change of changes) {
        const odd = await tx.odds.findUnique({
          where: { matchId_market_selection: { matchId, market: change.market, selection: change.selection } }
        });
        if (!odd) throw new Error(`Odds not found for ${change.market} ${change.selection}`);

        const oldValue = Number(odd.value);
        const oldEnabled = odd.enabled;
        const newValue = change.value !== undefined ? Math.round(change.value * 100) / 100 : oldValue;
        const newEnabled = change.enabled !== undefined ? change.enabled : oldEnabled;

        if (newValue === oldValue && newEnabled === oldEnabled) continue;

        const originalValue = odd.originalValue ?? odd.value;

        await tx.odds.update({
          where: { id: odd.id },
          data: {
            value: newValue,
            enabled: newEnabled,
            originalValue,
            source: 'manual'
          }
        });

        await tx.oddsChange.create({
          data: {
            matchId,
            market: change.market,
            selection: change.selection,
            oldValue: oldValue,
            newValue: newValue,
            oldEnabled,
            newEnabled,
            adminId
          }
        });
        results.push({ market: change.market, selection: change.selection });
        oddsEvents.emit('oddsUpdate', {
          matchId,
          market: change.market,
          selection: change.selection,
          value: newValue,
          enabled: newEnabled
        });
      }
      return results;
    });
  },

  async resetOdds(matchId: string, adminId: string) {
    return await prisma.$transaction(async (tx) => {
      const odds = await tx.odds.findMany({ where: { matchId, source: 'manual' } });
      const results = [];
      for (const odd of odds) {
        const originalValue = odd.originalValue;
        if (originalValue === null) continue;

        const oldValue = Number(odd.value);
        const oldEnabled = odd.enabled;

        await tx.odds.update({
          where: { id: odd.id },
          data: {
            value: originalValue,
            source: 'estimated',
            enabled: true
          }
        });

        await tx.oddsChange.create({
          data: {
            matchId,
            market: odd.market,
            selection: odd.selection,
            oldValue,
            newValue: Number(originalValue),
            oldEnabled,
            newEnabled: true,
            adminId
          }
        });
        results.push({ market: odd.market, selection: odd.selection });
        oddsEvents.emit('oddsUpdate', {
          matchId,
          market: odd.market,
          selection: odd.selection,
          value: Number(originalValue),
          enabled: true
        });
      }
      return results;
    });
  },

  // Admin edits the basic data of a SCHEDULED match from the Admin → Meciuri
  // table: home/away team, competition, matchday and matchDate.
  //
  // Rules enforced here (the frontend is NOT a security boundary):
  //  - status must be SCHEDULED, otherwise refuse.
  //  - when the match already has BetSelection rows, only matchDate may
  //    change; homeTeamId / awayTeamId / competitionId / matchday are frozen.
  //  - externalId and the legacy `league` column are never touched.
  //  - existing odds are left alone.
  async updateMatch(
    id: string,
    data: {
      homeTeamId: string;
      awayTeamId: string;
      competitionId?: string;
      matchday: number;
      matchDate: string;
    }
  ) {
    const match = await prisma.match.findUnique({
      where: { id },
      select: {
        status: true,
        homeTeamId: true,
        awayTeamId: true,
        competitionId: true,
        matchday: true,
        externalId: true,
        league: true,
        matchDate: true,
      },
    });
    if (!match) throw new Error('Jogo não encontrado');

    // Rule 1: only SCHEDULED matches can be edited. For VOID, the operator
    // must explicitly UNVOID from the per-match page first; we never flip the
    // status from this endpoint.
    if (match.status !== 'SCHEDULED') {
      throw new Error('Meciul poate fi editat doar cât time este programat.');
    }

    // When the match already has bets, identity fields are frozen.
    const betSelectionCount = await prisma.betSelection.count({
      where: { matchId: id },
    });
    const hasBets = betSelectionCount > 0;

    // Validate: teams exist (the Zod schema already enforces the home ≠ away
    // check, but service-level validation must not rely on it).
    const [homeTeam, awayTeam] = await prisma.$transaction([
      prisma.team.findUnique({ where: { id: data.homeTeamId }, select: { id: true } }),
      prisma.team.findUnique({ where: { id: data.awayTeamId }, select: { id: true } }),
    ]);
    let competition: { id: string } | null = null;
    if (data.competitionId) {
      competition = await prisma.competition.findUnique({
        where: { id: data.competitionId },
        select: { id: true },
      });
    }
    if (!homeTeam) throw new Error(`Echipa gazdă nu a fost găsită: ${data.homeTeamId}`);
    if (!awayTeam) throw new Error(`Echipa oaspete nu a fost găsită: ${data.awayTeamId}`);
    if (data.competitionId && !competition) {
      throw new Error(`Competiția nu a fost găsită: ${data.competitionId}`);
    }
    if (data.matchday < 1) {
      throw new Error('Matchday must be at least 1');
    }

    // Same Europe/Bucharest interpretation as createManual(): the datetime-local
    // value carries no timezone; we treat it as Bucharest and store UTC.
    const { fromZonedTime } = await import('date-fns-tz');
    const utcMatchDate = fromZonedTime(data.matchDate, 'Europe/Bucharest');

    const update: Prisma.MatchUncheckedUpdateInput = {
      matchDate: utcMatchDate,
      matchday: data.matchday,
      homeTeamId: data.homeTeamId,
      awayTeamId: data.awayTeamId,
      competitionId: data.competitionId ?? null,
    };

    if (hasBets) {
      // When bets exist, we only permit changing matchDate. Detect any attempt
      // to move the identity fields and reject with a clear message.
      const changed: string[] = [];
      if (data.homeTeamId !== match.homeTeamId) changed.push('homeTeamId');
      if (data.awayTeamId !== match.awayTeamId) changed.push('awayTeamId');
      if ((data.competitionId ?? null) !== (match.competitionId ?? null)) changed.push('competitionId');
      if (data.matchday !== match.matchday) changed.push('matchday');
      if (changed.length > 0) {
        throw new Error(
          `Meciul are deja pariuri și pot fi modificate doar data și ora (câmpurile ${changed.join(', ')} sunt blocate).`
        );
      }
      // Freeze identity fields; only matchDate may actually differ.
      delete update.homeTeamId;
      delete update.awayTeamId;
      delete update.competitionId;
      delete update.matchday;
    }

    await prisma.match.update({ where: { id }, data: update });

    const updated = await prisma.match.findUnique({
      where: { id },
      include: { odds: true, homeTeam: true, awayTeam: true, competition: true },
    });
    if (!updated) throw new Error('Jogo não encontrado após atualização');
    return { ...serializeMatch(updated), odds: mapOdds(updated.odds) };
  },

  async getOddsHistory(matchId: string) {
    return await prisma.oddsChange.findMany({
      where: { matchId },
      include: { admin: { select: { name: true } } },
      orderBy: { createdAt: 'desc' }
    });
  },
}