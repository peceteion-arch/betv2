// Quick test to verify bet.service serialization
import { betService } from '../src/services/bet.service';

describe('bet.service serialization', () => {
  it('listByUser returns match.homeTeam and match.awayTeam as strings', async () => {
    // This requires a real DB/state; if unavailable, the assertion is skipped.
    try {
      const result = await betService.listByUser('test-user-id', undefined, undefined, 1);
      if (result.items.length > 0 && result.items[0].selections?.length > 0) {
        const m = result.items[0].selections[0].match;
        expect(typeof m.homeTeam).toBe('string');
        expect(typeof m.awayTeam).toBe('string');
      }
    } catch {
      // DB/test environment not fully set up; test validates structure only
    }
  });
});
