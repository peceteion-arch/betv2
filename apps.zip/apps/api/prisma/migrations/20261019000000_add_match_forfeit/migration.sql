-- Add isForfeit column to matches table to track matches decided by forfeit/awarded result.
-- Forfeit matches keep their sport score for display and settlement purposes, but are
-- excluded from the statistical engine's historical rating calculations.

ALTER TABLE "matches" ADD COLUMN "is_forfeit" BOOLEAN NOT NULL DEFAULT false;
