import { Prisma } from '@prisma/client';
import { prisma } from '../../lib/prisma';
import { NormalizedMatch } from './match-history.types';
import { isMatchEligible } from '../features/match-eligibility.utils';

// Shape returned by the provider queries: the Match row plus its two teams.
type MatchWithTeams = Prisma.MatchGetPayload<{
  include: { homeTeam: true; awayTeam: true };
}>;

function normalizeMatch(match: MatchWithTeams): NormalizedMatch {
  return {
    matchId: match.id,
    homeTeamId: match.homeTeamId,
    awayTeamId: match.awayTeamId,
    homeTeamName: match.homeTeam.name,
    awayTeamName: match.awayTeam.name,
    competitionId: match.competitionId ?? null,
    matchday: match.matchday,
    matchDate: match.matchDate,
    status: match.status,
    homeScore: match.homeScore ?? null,
    awayScore: match.awayScore ?? null,
  };
}

/**
 * Validates the asOf parameter for temporal safety.
 * Must be a valid Date object.
 */
function validateAsOf(asOf: Date): void {
  if (asOf === undefined || asOf === null) {
    throw new TypeError('asOf must be a valid Date');
  }
  if (!(asOf instanceof Date) || isNaN(asOf.getTime())) {
    throw new TypeError('asOf must be a valid Date');
  }
}

export const matchHistoryProvider = {
  // Temporal cutoff rule (PASUL 1.5A): only matches BEFORE asOf are eligible.
  // Comparison is strict: matchDate < asOf. A match exactly at asOf or after is excluded.
  async getTeamMatches(teamId: string, asOf: Date): Promise<NormalizedMatch[]> {
    validateAsOf(asOf);
    const matches = await prisma.match.findMany({
      where: {
        OR: [{ homeTeamId: teamId }, { awayTeamId: teamId }],
        matchDate: { lt: asOf },
      },
      include: {
        homeTeam: true,
        awayTeam: true,
      },
      orderBy: { matchDate: 'asc' },
    });
    return matches.map(normalizeMatch);
  },

  async getRecentTeamMatches(teamId: string, limit: number, asOf: Date): Promise<NormalizedMatch[]> {
    validateAsOf(asOf);
    const matches = await prisma.match.findMany({
      where: {
        OR: [{ homeTeamId: teamId }, { awayTeamId: teamId }],
        matchDate: { lt: asOf },
      },
      include: {
        homeTeam: true,
        awayTeam: true,
      },
      orderBy: { matchDate: 'desc' },
      take: limit,
    });
    // Return in ASC chronological order from oldest to newest of selected
    return matches.reverse().map(normalizeMatch);
  },

  async getHeadToHead(teamAId: string, teamBId: string, asOf: Date): Promise<NormalizedMatch[]> {
    validateAsOf(asOf);
    if (teamAId === teamBId) {
      throw new Error('teamAId and teamBId must be different');
    }
    const matches = await prisma.match.findMany({
      where: {
        OR: [
          { homeTeamId: teamAId, awayTeamId: teamBId },
          { homeTeamId: teamBId, awayTeamId: teamAId },
        ],
        matchDate: { lt: asOf },
      },
      include: {
        homeTeam: true,
        awayTeam: true,
      },
      orderBy: { matchDate: 'asc' },
    });
    const normalized = matches.map(normalizeMatch);
    return normalized.filter(m => isMatchEligible(m, asOf));
  },

  // PASUL 1.7C: Get all eligible matches for a competition before asOf
  async getCompetitionMatches(competitionId: string, asOf: Date): Promise<NormalizedMatch[]> {
    validateAsOf(asOf);
    const matches = await prisma.match.findMany({
      where: {
        competitionId,
        matchDate: { lt: asOf },
      },
      include: {
        homeTeam: true,
        awayTeam: true,
      },
      orderBy: { matchDate: 'asc' },
    });
    const normalized = matches.map(normalizeMatch);
    return normalized.filter(m => isMatchEligible(m, asOf));
  },
};
