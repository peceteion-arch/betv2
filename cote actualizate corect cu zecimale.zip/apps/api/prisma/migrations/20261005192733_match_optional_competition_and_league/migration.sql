-- AlterTable
ALTER TABLE "matches" ADD COLUMN     "league" TEXT,
ALTER COLUMN "competition_id" DROP NOT NULL;
