/*
  Warnings:

  - You are about to drop the column `away_crest` on the `matches` table. All the data in the column will be lost.
  - You are about to drop the column `away_team` on the `matches` table. All the data in the column will be lost.
  - You are about to drop the column `country` on the `matches` table. All the data in the column will be lost.
  - You are about to drop the column `group_stage` on the `matches` table. All the data in the column will be lost.
  - You are about to drop the column `home_crest` on the `matches` table. All the data in the column will be lost.
  - You are about to drop the column `home_team` on the `matches` table. All the data in the column will be lost.
  - You are about to drop the column `league` on the `matches` table. All the data in the column will be lost.
  - Added the required column `away_team_id` to the `matches` table without a default value. This is not possible if the table is not empty.
  - Added the required column `competition_id` to the `matches` table without a default value. This is not possible if the table is not empty.
  - Added the required column `home_team_id` to the `matches` table without a default value. This is not possible if the table is not empty.
  - Made the column `matchday` on table `matches` required. This step will fail if there are existing NULL values in that column.

*/
-- AlterTable
ALTER TABLE "matches" DROP COLUMN "away_crest",
DROP COLUMN "away_team",
DROP COLUMN "country",
DROP COLUMN "group_stage",
DROP COLUMN "home_crest",
DROP COLUMN "home_team",
DROP COLUMN "league",
ADD COLUMN     "away_team_id" TEXT NOT NULL,
ADD COLUMN     "competition_id" TEXT NOT NULL,
ADD COLUMN     "home_team_id" TEXT NOT NULL,
ALTER COLUMN "matchday" SET NOT NULL;

-- CreateIndex
CREATE INDEX "matches_competition_id_matchday_idx" ON "matches"("competition_id", "matchday");

-- CreateIndex
CREATE INDEX "matches_home_team_id_idx" ON "matches"("home_team_id");

-- CreateIndex
CREATE INDEX "matches_away_team_id_idx" ON "matches"("away_team_id");

-- AddForeignKey
ALTER TABLE "matches" ADD CONSTRAINT "matches_home_team_id_fkey" FOREIGN KEY ("home_team_id") REFERENCES "teams"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "matches" ADD CONSTRAINT "matches_away_team_id_fkey" FOREIGN KEY ("away_team_id") REFERENCES "teams"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "matches" ADD CONSTRAINT "matches_competition_id_fkey" FOREIGN KEY ("competition_id") REFERENCES "competitions"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
